package com.shah.AppPractice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppPracticeApplicationTests {

	@Test
	void contextLoads() {
	}

}
