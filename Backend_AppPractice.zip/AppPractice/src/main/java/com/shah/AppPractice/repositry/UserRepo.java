package com.shah.AppPractice.repositry;

import com.shah.AppPractice.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
// jparepositry basically provide all the functionaly of find deleting with mysql
public interface UserRepo extends JpaRepository<User, Long> {
}
