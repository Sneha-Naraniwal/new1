package com.shah.AppPractice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppPracticeApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppPracticeApplication.class, args);
	}

}
